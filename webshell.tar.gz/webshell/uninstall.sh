#!/bin/sh

killall webshell >/dev/null 2>&1
rm -rf /koolshare/bin/webshell
rm -rf /koolshare/scripts/webshell*
rm -rf /koolshare/scripts/uninstall_webshell.sh
rm -rf /koolshare/webs/Module_webshell.asp

